Economic Briefing — Josh Waldman
Refreshed: 2026-09-26T01:06:38.748Z
Each CSV contains the displayed table, its units and source links. Nulls mean unavailable.
series.json contains source observations in their ORIGINAL source units.
Totals and averages use the exact baseline periods described below.

Payroll employment by industry
Payroll jobs, seasonally adjusted. Net change is the ending level minus the starting level for the stated period. “Since” comparisons end in the latest month shown. Jan 2021–Jan 2025 compares those two January levels. Monthly averages summarize observed job changes over the stated period; they are not forecasts. Averages require every month in the period. Subsets overlap their parent industries.
Source: BLS Current Employment Statistics via FRED. Employment counts payroll jobs, not unique workers. Changes use the current revised data; missing observations remain unavailable.

Unemployment rates by demographic group
Seasonally adjusted. Unemployment rates measure unemployed people as a share of the labor force. Ages 16 and over unless stated otherwise. Hispanic or Latino is an ethnicity and may overlap any race. Changes in rates are percentage points.
Source: BLS Current Population Survey via FRED. Comparison months must be present in the source data.

Consumer price inflation: CPI and PCE
Percent changes in price indexes. The 1-month change is seasonally adjusted (SA). CPI and PCE measure different baskets of consumer spending; core measures exclude food and energy. CPI 12-month changes are not seasonally adjusted (NSA); PCE 12-month changes use SA indexes, as indicated.
Sources: BLS Consumer Price Index and BEA Personal Consumption Expenditures Price Index via FRED. All changes compare observed index values.

Retail prices: gasoline and basic goods
Dollar prices for the stated quantity. The prior period is the preceding month for goods and the preceding week for fuel. Twelve-month comparisons use the same month a year earlier, or 52 weeks earlier for weekly fuel prices. Published adjustment is shown for each series.
Sources: BLS U.S. city average retail prices and EIA U.S. retail fuel prices via FRED. Average retail prices describe dollar costs; CPI and PCE indexes are the measures of inflation.

Manufacturing and auto employment
Payroll jobs, seasonally adjusted. Net change is the ending level minus the starting level for the stated period. “Since” comparisons end in the latest month shown. Jan 2021–Jan 2025 compares those two January levels. Monthly averages summarize observed job changes over the stated period; they are not forecasts. Averages require every month in the period. Subsets overlap their parent industries. The defined auto total combines motor vehicles and parts manufacturing with motor vehicle and parts dealers. It excludes auto repair, wholesale and other auto-related industries.
Source: BLS Current Employment Statistics via FRED. Component totals use dates available in every source. Michigan, Ohio, Wisconsin, Pennsylvania and Minnesota are selected states, not a complete region.

U.S. real GDP: official BEA figures
Growth is the BEA-published percent change from the preceding quarter at a seasonally adjusted annual rate (SAAR). Each growth entry describes its own quarter; it is not a 4-quarter change or a forecast. The GDP level is inflation-adjusted output in billions of chained 2017 dollars at an annual rate.
BEA NIPA Tables 1.1.1 and 1.1.6 via FRED. Values are read directly from the published series. For growth during a single quarter and cumulative comparisons, use G7 real GDP.

G7 real GDP growth and cumulative changes
All countries use the latest quarter available for every country, with seasonally adjusted real GDP. Quarterly change is growth during one quarter, not an annual rate. The 4-quarter column compares with the same quarter a year earlier, not annual-average GDP. Cumulative columns compare levels at the stated endpoints and are not average annual growth rates.
BEA and national statistical sources via FRED. Pandas calculates percentage changes from each country’s real GDP series; national-currency levels are omitted from this comparison. Q1 baselines are full quarters, not January-only observations or exact presidential-term boundaries. The common comparison quarter avoids mixing periods when national release dates differ; the U.S. tab separately reports the latest BEA quarter.

Business applications
Monthly application counts, seasonally adjusted. Applications are not counts of businesses opened. High-propensity applications are a subset of total applications with characteristics associated with a higher likelihood of becoming an employer business.
Source: U.S. Census Bureau Business Formation Statistics via FRED. Changes compare observed monthly counts.

Unemployment insurance claims
Seasonally adjusted weekly levels. The comparison columns show claim counts, not changes. The 4-week average is the published average of initial claims. Continued claims generally refer to an earlier week than initial claims.
Source: U.S. Department of Labor, Employment and Training Administration via FRED. Comparisons require the exact reporting week.

Stock market price indexes
Observed daily closing index levels and price returns, not seasonally adjusted. Returns exclude dividends. Year-to-date starts from the last available close on or before the preceding December 31.
Sources: S&P Dow Jones Indices and Nasdaq via FRED. Calendar comparisons use a prior available closing value within seven days of the comparison date. These are closing prices, not intraday quotes.

Federal budget deficit
Positive values indicate a deficit; negative values indicate a surplus. Dollar amounts are billions of U.S. dollars, while the fiscal-year deficit-to-GDP ratio is a percent. The federal fiscal year starts in October. Monthly balances are not seasonally adjusted.
Sources: U.S. Treasury and OMB via FRED. Fiscal-year-to-date and trailing-12-month totals require every reported month.

Prime-age labor force participation and employment
People ages 25–54, seasonally adjusted. Labor force participation is the share of the population working or actively seeking work. The employment-to-population ratio is the share employed. Changes in either rate are percentage points.
Source: BLS Current Population Survey via FRED. Comparison months must be present in the source data.

Job openings, quits, underemployment and wages
Job openings are in thousands. The quits rate is quits as a percent of employment. U-6 includes unemployed and marginally attached people and people working part time for economic reasons, relative to the labor force plus the marginally attached. Average hourly earnings cover all employees on private nonfarm payrolls and are nominal dollars per hour.
Source: BLS via FRED. Published seasonal adjustment is retained. The latest reporting month can differ across indicators.

Changes since February 28, 2026
Changes since the user-selected February 28, 2026 start date. Daily and weekly baselines are actual observations before that date. Monthly baselines use January 2026 because February includes the start of the war. Baseline and latest dates are shown for every series. These comparisons describe changes over the period, not the effects caused by the war. Latest observation date identifies when the value was measured; the page refresh timestamp identifies when the data were retrieved. WTI and Brent are EIA daily spot-price observations published with a delay, not live futures quotes.
Sources: FRED and the original data providers linked in each row. Changes use the unit shown: jobs or claims for counts, index points for indexes, and percentage points for unemployment rates. Relative change (%) is the proportional change from the baseline value. Daily baselines must fall within seven days before the start; weekly baselines within fourteen days. Missing values remain unavailable.
