Economic Briefing — Josh Waldman
Refreshed: 2026-09-25T01:28:03.241Z
Each CSV contains the displayed table, its units and source links. Nulls mean unavailable.
series.json contains source observations in their ORIGINAL source units.
Totals and averages use the exact baseline periods described below.

Employment by industry
Changes are people. Jan 2021–Jan 2025 uses exact January levels and 48 observed monthly changes. Since Jan 2025 uses the exact January 2025 level and observed monthly changes to the row’s latest month. Totals require both endpoints; averages require every intervening month. Subsets overlap and should not be added to parent industries.
BLS establishment survey via FRED. Published seasonal adjustment is retained. Pandas converts raw thousands of people to people; monthly averages are means of observed monthly differences.

Unemployment by race and demographic
Seasonally adjusted. Ages 16 and over unless otherwise noted. Hispanic or Latino ethnicity may be of any race; these groups overlap.
BLS household survey via FRED. pp means percentage points. Observed differences are computed with pandas.

CPI and PCE inflation
Observed month-over-month and year-over-year changes in published seasonally adjusted price indexes. CPI and PCE have different coverage and weights. Only configured source series are included.
BLS CPI and BEA PCE via FRED. Changes use pandas pct_change with no missing-value fill. SA CPI index-based YoY can differ slightly from the headline NSA convention.

Gas prices and everyday goods
Actual dollar prices per stated unit. These series retain their published seasonal adjustment; most average retail prices are NSA. They are national averages, not a local shopping quote. The prior period is one month for monthly prices or one week for weekly fuel prices.
BLS average retail prices and EIA fuel prices via FRED. Weekly YoY compares 52 weeks earlier; monthly YoY compares the same month a year earlier. Pandas uses exact observations; missing periods remain unavailable.

Manufacturing, auto manufacturing and dealers
Levels and changes are people. Jan 2021–Jan 2025 uses exact January levels and 48 observed monthly changes. Since Jan 2025 uses the exact January 2025 level and observed monthly changes to the row’s latest month. Totals require both endpoints; averages require every intervening month. Subsets overlap and should not be added to parent industries. “Total auto jobs” means motor vehicles and parts manufacturing plus motor vehicle and parts dealers; it does not cover every auto-related business.
BLS establishment-survey data via FRED, using published seasonal adjustment. Pandas aligns derived components on dates present in every source before summing. The selected states are Michigan, Ohio, Wisconsin, Pennsylvania and Minnesota, not a complete geographic region.

Real GDP: U.S. and G7
Inflation-adjusted output. QoQ is the observed change from the preceding quarter. Compare growth rates across countries: published levels use different currencies, reference years and source conventions. Q1 baselines represent full quarters, not January alone.
BEA and national statistical sources via FRED. Changes are computed with pandas from observed quarterly levels. SAAR identifies an annual-rate level published by the source; the dashboard does not convert observed quarterly growth into an annual rate.

Business applications
Monthly applications, seasonally adjusted. High-propensity applications are a subset of total applications, not additional business formations.
U.S. Census Bureau via FRED. Changes are computed with pandas from observed application counts.

Initial and continued claims
Seasonally adjusted. Continued claims generally refer to an earlier week than initial claims.
U.S. Employment and Training Administration via FRED. Comparisons require exact dates; missing observations remain unavailable.

Stock market indexes
Daily closing price indexes, not live prices. Changes exclude dividends. Market series are not seasonally adjusted.
S&P Dow Jones Indices and Nasdaq via FRED. Calendar lookbacks use a prior observed close within seven days. Pandas computes returns from those observed prices.

Federal deficit measures
Positive values indicate a deficit; negative values indicate a surplus. Fiscal year to date begins in October. Published budget balances are NSA.
Treasury and OMB via FRED. Pandas sums observed monthly balances only when every required month is available.

Prime-age participation and employment
People ages 25–54. Seasonally adjusted. Participation includes employed people and unemployed people seeking work.
BLS household survey via FRED. pp means percentage points. Differences are computed with pandas.

Job openings, quits, underemployment and wages
Published seasonal adjustment is retained. Job openings and quits come from JOLTS; U-6 is a broader measure of labor underutilization. Wages are nominal dollars per hour.
BLS via FRED. Observation months differ across releases.

Changes since February 28, 2026
User-selected start: February 28, 2026. Daily and weekly baselines are the last available observation before that date; monthly baselines use January 2026 because February spans the start of the war. Each baseline is shown explicitly. These comparisons describe changes over time and do not attribute them to the war.
Sources via FRED. Pandas uses observed baselines within 7 days for daily data and 14 days for weekly data; missing monthly baselines remain unavailable. Rate differences under absolute change are percentage points; percent change is relative to the baseline.
