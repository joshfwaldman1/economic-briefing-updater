Economic Briefing — Josh Waldman
Refreshed: 2026-09-23T23:02:35.813Z
Each CSV contains the displayed table, its units and source links. Nulls mean unavailable.
series.json contains source observations in their ORIGINAL source units.
Totals and averages use the exact baseline periods described below.

Employment by industry
Levels and changes are people. Jan 2021–Jan 2025 uses exact January levels and 48 elapsed monthly changes. Since Jan 2025 uses the exact January 2025 level and elapsed months to the row’s latest month. Totals require both endpoints; monthly averages also require every intervening month. Subsets overlap and should not be added to parent industries.
BLS establishment survey, retrieved through FRED. Published seasonal adjustment is retained. Raw FRED employment levels are thousands of people; displayed values are multiplied by 1,000.

Unemployment by race and demographic
Seasonally adjusted. Ages 16 and over unless otherwise noted. Hispanic or Latino ethnicity may be of any race; these groups overlap.
BLS household survey via FRED. pp means percentage points.

CPI and PCE inflation
Changes calculated from published seasonally adjusted price indexes. CPI and PCE have different coverage and weights. PCE core goods, core services and housing remain unavailable until exact monthly sources are configured.
BLS CPI and BEA PCE via FRED. SA CPI index-based YoY can differ slightly from the headline NSA convention. Annualization compounds index ratios.

Gas prices and everyday goods
Actual dollar prices per stated unit. These series retain their published seasonal adjustment; most average retail prices are NSA. They are national averages, not a local shopping quote. The prior period is one month for monthly prices or one week for weekly fuel prices.
BLS average retail prices and EIA fuel prices via FRED. Weekly YoY compares 52 weeks earlier; monthly YoY compares the same month a year earlier. Missing periods are never filled forward.

Manufacturing, auto manufacturing and dealers
Levels and changes are people. Jan 2021–Jan 2025 uses exact January levels and 48 elapsed monthly changes. Since Jan 2025 uses the exact January 2025 level and elapsed months to the row’s latest month. Totals require both endpoints; monthly averages also require every intervening month. Subsets overlap and should not be added to parent industries. “Total auto jobs” means motor vehicles and parts manufacturing plus motor vehicle and parts dealers; it does not cover every auto-related business. State components are labeled explicitly.
BLS establishment-survey data via FRED, seasonally adjusted. Derived totals use only dates common to all components. The selected states are Michigan, Ohio, Wisconsin, Pennsylvania and Minnesota, not a complete geographic region.

Real GDP: U.S. and G7
Inflation-adjusted output. Compare growth rates across countries: published levels use different currencies, reference years and annualization conventions. January baselines represent Q1, not monthly GDP. Quarterly growth is compounded to an annual rate. SAAR means the published level is seasonally adjusted at an annual rate.
BEA and national statistical sources via FRED. Real GDP is quarterly and revised after initial estimates; Q1 2025 is not a clean January-only baseline.

Business applications
Monthly applications, seasonally adjusted. High-propensity applications are a subset of total applications, not additional business formations.
U.S. Census Bureau via FRED.

Initial and continued claims
Seasonally adjusted. Continued claims generally refer to an earlier week than initial claims.
U.S. Employment and Training Administration via FRED. Comparisons require the exact week; missing dates remain unavailable.

Stock market indexes
Daily closing price indexes, not live prices. Changes exclude dividends. Market series are not seasonally adjusted.
S&P Dow Jones Indices and Nasdaq via FRED. Calendar lookbacks use a preceding available close within seven days.

Federal deficit measures
Positive values indicate a deficit; negative values indicate a surplus. Fiscal year to date begins in October. Published budget balances are NSA.
Treasury and OMB via FRED. Monthly balances are summed only when every required month is available.

Prime-age participation and employment
People ages 25–54. Seasonally adjusted. Participation includes employed people and unemployed people seeking work.
BLS household survey via FRED. pp means percentage points.

Job openings, quits, underemployment and wages
Published seasonal adjustment is retained. Job openings and quits come from JOLTS; U-6 is a broader measure of labor underutilization. Wages are nominal dollars per hour.
BLS via FRED. Observation months differ across releases.

Changes since February 28, 2026
Reference date: February 28, 2026. Daily and weekly baselines are the last available observation before that date; monthly baselines use January 2026 because February spans the start of the war. Each baseline is shown explicitly. These comparisons describe changes over time and do not attribute them to the war.
Sources via FRED. Daily baselines must be within 7 days and weekly baselines within 14 days of the cutoff; missing monthly baselines stay unavailable. Percentage-point changes in rate series appear under absolute change; percent change is relative to the baseline.
